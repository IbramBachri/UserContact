package com.example.githubusersubsmision2.DarkTheme

import android.content.Context

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.ViewModelProvider
import com.example.githubusersubsmision2.R
import com.google.android.material.switchmaterial.SwitchMaterial
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.preferencesDataStore


//private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class DarkActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dark)


        val switchTheme = findViewById<SwitchMaterial>(R.id.switch_theme)

        //val pref = SettingPreferences.getInstance(dataStore)
        //val darkViewModel = ViewModelProvider(this, ViewModelFactory(pref)).get(
            //DarkViewModel::class.java
        //)
        darkViewModel.getThemeSettings().observe(this,
            { isDarkModeActive: Boolean ->
                if (isDarkModeActive) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    switchTheme.isChecked = true
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    switchTheme.isChecked = false
                }
            })

        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            darkViewModel.saveThemeSetting(isChecked)
        }
    }
}